﻿using System;

namespace OOP_Bootcamp
{
    class demo
    {
        protected int id = 10;
        protected string name = "Devanshi";
        public void ABC()
        {
            Console.WriteLine("this is method ABC");
        }
        //--------------Method Overloading------------
        public void ABC(int a, int b)
        {
            Console.WriteLine("A:" + a);
            Console.WriteLine("B:" + b);
        }
    }

    class childDemo : demo
    {
        public void XYZ()
        {
            Console.WriteLine("id:" + id);
            Console.WriteLine("Name:" + name);
        }
        public void IJK()
        {
            Console.WriteLine("THIS IS IJK");
        }
    }

    class subchildDemo : childDemo
    {
        //----------overriding
        public void IJK()
        {
            Console.WriteLine("WE CAN OVERRIDE");
        }
    }
    //-----------encapulation-----------
    public class Encapsulation
    {
        private int a;
        protected int b;
        public int c;
    }
    public class EncapsulationDemo : EncapsulationDemo
    {
        public void EDemoFun()
        {
            b = 10;
        }
    }
    //Abstraction
    abstract class AbsParent
    {
        public void demoAbs()
        {
            Console.WriteLine("normal method of normal class:AbsParent is called");
        }
        public abstract void demoAbsFun();
    }
    abstract class AbsChild : AbsParent
    {
        public abstract void DemoAbs_Fun();
        public void normal_fun()
        {
            Console.WriteLine("Normal Method of Class : Abs child is called");
        }
        public override void demoAbsFun()
        {
            Console.WriteLine("abstract method of abstract class named :Abs parent is called in Abschild");
        }
    }
    class AbsChildFun : AbsChild
    {
        public override void DemoAbs_Fun()
        {
            Console.WriteLine("Abstract method of abstract class name AbsChild is called ");
        }
        public void demoChildFun()
        {
            Console.WriteLine("Abstract method of child class is called");
        }
        public void demoAbstract_Fun()
        {
            Console.WriteLine("Abstract method of abstract class is called in child class");
        }
    }
    //----------static-----------
    public static class StaticClass
    {
        public static int a;
    }
    public class StaticClass2
    {
        public int a1;
        public static int b;
    }
    class NotSealed
    {
        public int a = 10;
    }
    sealed class Sealed_class : NotSealed
    {
        public int b;
    }
    public partial class P1
    {
        public int p1;
    }
    public partial class P2
    {
        public int p2;
    }
    public class P3:P1
    {
        public int child;
    }
    class Program
    {
        static void Main(string[] args)
        {
            childDemo d = new childDemo();
            subchildDemo d2 = new subchildDemo();
            d2.XYZ();
            d2.ABC();
            d2.ABC(1, 5);
            d2.IJK();
            d.IJK();

            Encapsulation en = new Encapsulation();
            en.c = 1000;
            Console.WriteLine("encapsulation classs:" + en.c);

            AbsChildFun ABSDEmo1 = new AbsChildFun();
            ABSDEmo1.normal_fun();
            ABSDEmo1.DemoAbs_Fun();
            ABSDEmo1.demoChildFun();
            ABSDEmo1.demoAbstract_Fun();
            ABSDEmo1.demoAbs();

            AbsChild c = new AbsChildFun();
            c.normal_fun();
            c.demoAbs();
            c.demoAbsFun();
            c.DemoAbs_Fun();

            StaticClass.a = 10;
            StaticClass2 s = new StaticClass2();
            s.a1 = 10;
            StaticClass2.b = 20;

            P1 par = new P1();
            par.p1 = 100;
            P3 par1 = new P3();
            par1.p1 = 500;
            

        }
    }
}
