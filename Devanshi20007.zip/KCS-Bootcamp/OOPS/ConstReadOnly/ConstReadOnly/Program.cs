﻿
using System;
namespace SK
{
    class Demo
    {
        public const int a = 10;
        readonly int b = 10;
        int c = 30;
        public Demo(int n)
        {
            b = n;
        }
        public static void Main(string[] args)
        {
            Demo d = new Demo(40);
            Console.WriteLine(d.b);
            d.c = 50;
            Console.ReadKey();

        }

    }
}
