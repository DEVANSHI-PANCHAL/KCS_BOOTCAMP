﻿using System;

namespace DependencyInjection
{
    //-------------constructor injection------------
    public interface I1
    {
        void demo();
    }
    class Child1:I1
    {
        public void demo()
        {
            Console.WriteLine("demo function called of child1 class-Constructor injection");
        }

    }
    class Child2 : I1
    {
        public void demo()
        {
            Console.WriteLine("demo function called of child2 class-Constructor injection");
        }

    }
    //--------------constructor injection class------------
    public class ConstructorInjection
    {
        private I1 i1;//ref variable

        public ConstructorInjection(I1 i1)
        {
            this.i1 = i1;
        }
        public void demo()
        {
            i1.demo();
        }
    }
    //------------Property injection-------------
    public interface I2
    {
        void DemoPropertyInjection(string message);
    }
    class LogWriterClass : I2
    {
        public void DemoPropertyInjection(string message)
        {
            Console.WriteLine("DemoPropertyInjection Method Called of LogWriterClass - Property Injection.");
        }
    }
    class LogWriterClass2 : I2
    {
        public void DemoPropertyInjection(string message)
        {
            Console.WriteLine("DemoPropertyInjection Method Called of LogWriterClass2 - Property Injection.");
        }
    }
    class PropertyInjectionClass
    {
        I2 _i2 = null;
        public void DemoPropertyInjectionFunctionOfClass(I2 _i2, string messages)
        {
            this._i2 = _i2;
            _i2.DemoPropertyInjection(messages);
        }
    }
    //------------Method Injection-----------
    public interface I3
    {
        void Demo3();
    }
    public class ServiceClass : I3
    {
        public void Demo3()
        {
            Console.WriteLine("Demo3 Method Overriding - Service Class.");
        }
    }
    public class ClientClass
    {
        private I3 _i3;
        public void ClientClassMethod(I3 _i3)
        {
            this._i3 = _i3;
            Console.WriteLine("Client Class Method Statement Called.");
            this._i3.Demo3();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            ConstructorInjection c = null;
            c = new ConstructorInjection(new Child1());
            c = new ConstructorInjection(new Child2());
            c.demo();
            //-------------property injection
            PropertyInjectionClass PIC = new PropertyInjectionClass();
            PIC.DemoPropertyInjectionFunctionOfClass(new LogWriterClass(), "Message - Property Value Passed.");
            PIC.DemoPropertyInjectionFunctionOfClass(new LogWriterClass2(), "Message - Property Value Passed.");
            ClientClass CCLS = new ClientClass();
            CCLS.ClientClassMethod(new ServiceClass());
        }
    }
}
