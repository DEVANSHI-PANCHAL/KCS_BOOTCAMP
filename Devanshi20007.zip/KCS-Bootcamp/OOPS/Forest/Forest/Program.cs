﻿using System;

namespace Forest
{

    class Forest
    {
        public string name;
        public int trees;
        public int age;
        public string biome;

    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Forest f = new Forest();
            f.name = "Congo";
            Console.WriteLine(f.name);
        }
    }
}
