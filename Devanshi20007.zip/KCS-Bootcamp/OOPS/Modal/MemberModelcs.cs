﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelClassCollectionList
{
    //Model
    class MemberModelcs
    {
        //Property
        public int MemberId { get; set; }
        public string MemberFirstName { get; set; }
        public string MemberLastName { get; set; }
        public string MemberContactNo { get; set; }
        public string MemberEmailId { get; set; }
        public char MemberGender { get; set; }

        public MemberModelcs() { }

    }
}
