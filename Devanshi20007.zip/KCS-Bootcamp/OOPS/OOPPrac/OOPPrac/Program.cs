﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPPrac
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Devanshi");
            Console.WriteLine("how old are you?");
            String input = Console.ReadLine();
            Console.WriteLine($"you are {input} years old");
            Console.ReadKey();

            Forest f = new Forest();
            f.name = "Congo";
            f.trees = 0;
            Console.WriteLine(f.name);
        }
    }

    class Forest
    {
        public string name;
        public int trees;
    }
}
